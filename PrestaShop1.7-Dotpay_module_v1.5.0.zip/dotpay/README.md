# PrestaShop Dotpay payment module for  PrestaShop 1.7
=====================


#### Wtyczka dla PrestaShop dodająca bramkę płatności Dotpay ####

[![](https://img.shields.io/github/release/dotpay/PrestaShop-1.7.svg?style=for-the-badge)](https://github.com/dotpay/PrestaShop-1.7/releases/latest "Download")

### Najnowsza wersja modułu oraz instrukcja instalacji:
https://github.com/dotpay/PrestaShop-1.7/releases/latest

--




 Jeśli używasz starszej wersji PrestaShop 1.6, dedykowany moduł dla twojej wersji znajdziesz pod adresem: https://github.com/dotpay/PrestaShop-1.6

---------------------------------------

#### PrestaShop plugin adding Dotpay payment gateway ####


### Latest plugin and installation manual version:
https://github.com/dotpay/PrestaShop-1.7/releases/latest




--
You can find module for older version PrestaShop 1.6: https://github.com/dotpay/PrestaShop-1.6
